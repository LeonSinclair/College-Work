/**
 * Class FacebookCircles: calculates the statistics about the friendship circles in facebook data.
 *
 * @author
 *
 * @version 01/12/15 02:03:28
 */
/*
 * simple idea is to have the public constructor then call a private constructor which creates a graph of user objects which we call
 * a circle, then adding friendships is just creating an edge between them, we'll also have to define an edge object so
 * 
 */
public class FacebookCircles {
	private int[] circles;
	private int[] size;
	private long count;
  /**
   * Constructor
   * @param numberOfFacebookUsers : the number of users in the sample data.
   * Each user will be represented with an integer id from 0 to numberOfFacebookUsers-1.
   */
  public FacebookCircles(int numberOfFacebookUsers) {
    // TODO
	circles = new int[numberOfFacebookUsers];
	for(int i = 0; i <numberOfFacebookUsers; i++)
	{
		circles[i]=i;
	}
	size = new int[numberOfFacebookUsers];
	for(int i = 0; i<size.length; i++)
	{
		size[i] = 1;
	}
	count = numberOfFacebookUsers;
  }
  

  /**
   * creates a friendship connection between two users, represented by their corresponding integer ids.
   * @param user1 : int id of first user
   * @param user2 : int id of second  user
   */
  public void friends( int user1, int user2 ) {

    // TODO
	//union - change the two sets to be equal to each other
	//whenever we do union we change the sizes for those two ids to be equal to the sum of the two sizes
	// then we sort the array - can't do since each id is associated with a position, cannot change the order
	int user1ID = circles[user1];
	int user2ID = circles[user2];
	int newSize = size[user1ID] + size[user2ID];
	if(user1ID!=user2ID)
	{
		for(int i = 0; i<circles.length; i++)
		{
			if(circles[i] == user1ID)
			{
				circles[i] = user2ID;
				size[i] = newSize;
			}
			else if(circles[i] == user2ID)
			{
				size[i] = newSize;
			}
		}
	}
	
  }
  
  /**
   * @return the number of friend circles in the data already loaded.
   */
  public int numberOfCircles() {
	//simple implementation is to iterate through the array and have a current id variable, whenever currentID changes
	//you can increment the count of circles
	int circlesCount = 1;
	int currentID = 0;
	for(int i = 0; i<circles.length; i++)
	{
		if(i!=currentID)
		{
			currentID = i;
			circlesCount++;
		}
	}
    return circlesCount;
  }

  /**
   * @return the size of the largest circle in the data already loaded.
   */
  public int sizeOfLargestCircle() {
	int largest = 0;
	for(int i = 0; i < size.length; i ++)
	{
		if(size[i]>size[largest])
			largest = i;
	}
    return largest;
  }

  /**
   * @return the size of the median circle in the data already loaded.
   */
  public int sizeOfAverageCircle() {
	// go through circles looking for each time the id changes, when it does we can go to size of that id and 
	// then add that to an average and when we exit the loop we divide it by the current id 
    // TODO
	int currentID = 0;
	int average = size[currentID];;
	for(int i = 0; i<circles.length; i++)
	{
		if(i!=currentID)
		{
			currentID = i;
			average += size[currentID];
		}
	}
	average = average/currentID;
    return 0;
  }

  /**
   * @return the size of the smallest circle in the data already loaded.
   */
  public int sizeOfSmallestCircle() {
	// return size[circles[count-1]]
	int smallest = 0;
	for(int i = 0; i < size.length; i ++)
	{
		if(size[i]<size[smallest])
			smallest = i;
	}
    return smallest;
  }


}
